import mongoose from 'mongoose';
import Message from './models/messageModel.mjs';

// Configuración de conexión reusable
const connectDB = async () => {
  if (mongoose.connection.readyState === 1) return;
  
  await mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
};

export const handler = async (event) => {
  try {
    // 1. Conectar a MongoDB
    await connectDB();
    
    // 2. Parsear parámetros de la solicitud
    const { userId, contactId, limit = 100, before } = event.queryStringParameters || {};
    
    // 3. Validar parámetros requeridos
    if (!userId || !contactId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          message: 'Se requieren userId y contactId'
        })
      };
    }

    // 4. Construir query para obtener la conversación bilateral
    const query = {
      $or: [
        { from: userId, to: contactId }, // Mensajes enviados por el usuario
        { from: contactId, to: userId }   // Mensajes recibidos del contacto
      ]
    };

    // 5. Opción de paginación (cargar mensajes más antiguos)
    if (before) {
      query.timestamp = { $lt: new Date(before) };
    }

    // 6. Ejecutar consulta con ordenamiento y límite
    const messages = await Message.find(query)
      .sort({ timestamp: -1 })      // Orden descendente (más nuevos primero)
      .limit(parseInt(limit))        // Limitar resultados
      .select('from to content timestamp read') // Seleccionar campos
      .lean();                       // Optimizar performance

    // 7. Formatear respuesta
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: {
          messages: messages.reverse(), // Ordenar cronológicamente
          meta: {
            count: messages.length,
            hasMore: messages.length === parseInt(limit),
            nextCursor: messages.length > 0 ? messages[0].timestamp : null
          }
        }
      })
    };
    
  } catch (error) {
    console.error('Error al obtener historial:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        message: 'Error interno al obtener el historial',
        error: error.message
      })
    };
  }
};